import { useState } from 'react';
import { Box, Container, Tabs, Tab, Paper, Avatar, Typography, IconButton, Tooltip } from '@mui/material';
import SportsFootballIcon from '@mui/icons-material/SportsFootball';
import SportsEsportsIcon from '@mui/icons-material/SportsEsports';
import MenuBookIcon from '@mui/icons-material/MenuBook';
import MovieIcon from '@mui/icons-material/Movie';
import EmailIcon from '@mui/icons-material/Email';
import LinkedInIcon from '@mui/icons-material/LinkedIn';
import GitHubIcon from '@mui/icons-material/GitHub';
import PhoneIcon from '@mui/icons-material/Phone';
import SchoolIcon from '@mui/icons-material/School';
import EmojiEventsIcon from '@mui/icons-material/EmojiEvents';
import WorkIcon from '@mui/icons-material/Work';

// Componentes de Tabs
import { FootballTab } from './components/Tabs/FootballTab';
import { VideoGamesTab } from './components/Tabs/VideoGamesTab';
import { BibleTab } from './components/Tabs/BibleTab';
import { AnimeTab } from './components/Tabs/AnimeTab';
import { SkillsCarousel } from './components/CV/SkillsCarousel';

// Datos del CV
import { cvData } from './data/cvData';

/**
 * Componente principal de la aplicación
 * CV Interactivo con diseño de una sola pantalla
 */
function App() {
  const [activeTab, setActiveTab] = useState(0);

  const handleTabChange = (_event: React.SyntheticEvent, newValue: number) => {
    setActiveTab(newValue);
  };

  return (
    <Box sx={{ minHeight: '100vh', backgroundColor: 'background.default' }}>
      {/* ========== CV EN UNA SOLA PANTALLA ========== */}
      <Box
        sx={{
          minHeight: '100vh',
          display: 'flex',
          alignItems: 'center',
          background: 'linear-gradient(135deg, #0a0a0a 0%, #1a0a0a 50%, #0a0a0a 100%)',
          position: 'relative',
          overflow: 'hidden',
          px: 2,
          '&::before': {
            content: '""',
            position: 'absolute',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            background: 'radial-gradient(circle at 50% 50%, rgba(220, 20, 60, 0.1) 0%, transparent 50%)',
            pointerEvents: 'none',
          },
        }}
      >
        <Container maxWidth={false} sx={{ maxWidth: '1800px', py: 3 }}>
          <Box
            sx={{
              display: 'grid',
              gridTemplateColumns: { 
                xs: '1fr', 
                md: '1fr 1.8fr 1fr' 
              },
              gap: 3,
              alignItems: 'start',
              width: '100%',
            }}
          >
            {/* ========== COLUMNA IZQUIERDA: Experiencia y Contacto ========== */}
            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2.5 }}>
              {/* Experiencia */}
              <Paper
                elevation={4}
                sx={{
                  p: 3,
                  borderRadius: 3,
                  backgroundColor: 'rgba(255, 255, 255, 0.95)',
                  backdropFilter: 'blur(10px)',
                }}
              >
                <Typography
                  variant="h6"
                  sx={{
                    mb: 2,
                    fontWeight: 600,
                    display: 'flex',
                    alignItems: 'center',
                    gap: 1,
                  }}
                >
                  <WorkIcon color="primary" />
                  Experiencia
                </Typography>

                {cvData.experience.map((exp) => (
                  <Box key={exp.id} sx={{ mb: 3, '&:last-child': { mb: 0 } }}>
                    <Typography variant="subtitle1" fontWeight={600} color="primary">
                      {exp.role}
                    </Typography>
                    <Typography variant="body2" color="text.secondary" gutterBottom>
                      {exp.company}
                    </Typography>
                    <Typography variant="caption" color="text.secondary" sx={{ fontStyle: 'italic' }}>
                      {exp.period}
                    </Typography>
                    <Typography variant="body2" sx={{ mt: 1, fontSize: '0.85rem' }}>
                      {exp.description}
                    </Typography>
                  </Box>
                ))}
              </Paper>

              {/* Contacto */}
              <Paper
                elevation={4}
                sx={{
                  p: 3,
                  borderRadius: 3,
                  backgroundColor: 'rgba(255, 255, 255, 0.95)',
                  backdropFilter: 'blur(10px)',
                }}
              >
                <Typography variant="h6" fontWeight={600} gutterBottom sx={{ textAlign: 'center' }}>
                  Contacto
                </Typography>

                <Box
                  sx={{
                    display: 'flex',
                    justifyContent: 'center',
                    flexWrap: 'wrap',
                    gap: 2,
                    mt: 2,
                  }}
                >
                  {cvData.contact.email && (
                    <Tooltip title={cvData.contact.email} arrow>
                      <IconButton
                        component="a"
                        href={`mailto:${cvData.contact.email}`}
                        sx={{
                          backgroundColor: 'primary.light',
                          color: 'white',
                          '&:hover': { backgroundColor: 'primary.main', transform: 'scale(1.1)' },
                        }}
                      >
                        <EmailIcon />
                      </IconButton>
                    </Tooltip>
                  )}

                  {cvData.contact.linkedin && (
                    <Tooltip title="LinkedIn" arrow>
                      <IconButton
                        component="a"
                        href={cvData.contact.linkedin}
                        target="_blank"
                        sx={{
                          backgroundColor: '#0077b5',
                          color: 'white',
                          '&:hover': { backgroundColor: '#005885', transform: 'scale(1.1)' },
                        }}
                      >
                        <LinkedInIcon />
                      </IconButton>
                    </Tooltip>
                  )}

                  {cvData.contact.github && (
                    <Tooltip title="GitHub" arrow>
                      <IconButton
                        component="a"
                        href={cvData.contact.github}
                        target="_blank"
                        sx={{
                          backgroundColor: '#333',
                          color: 'white',
                          '&:hover': { backgroundColor: '#000', transform: 'scale(1.1)' },
                        }}
                      >
                        <GitHubIcon />
                      </IconButton>
                    </Tooltip>
                  )}

                  {cvData.contact.phone && (
                    <Tooltip title={cvData.contact.phone} arrow>
                      <IconButton
                        component="a"
                        href={`tel:${cvData.contact.phone}`}
                        sx={{
                          backgroundColor: 'success.light',
                          color: 'white',
                          '&:hover': { backgroundColor: 'success.main', transform: 'scale(1.1)' },
                        }}
                      >
                        <PhoneIcon />
                      </IconButton>
                    </Tooltip>
                  )}
                </Box>
              </Paper>
            </Box>

            {/* ========== COLUMNA CENTRAL: Foto, Nombre, Sobre Mí y Habilidades ========== */}
            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2.5 }}>
              {/* Header con foto y nombre */}
              <Paper
                elevation={4}
                sx={{
                  p: 3,
                  borderRadius: 3,
                  textAlign: 'center',
                  backgroundColor: 'rgba(26, 26, 26, 0.95)',
                  backdropFilter: 'blur(10px)',
                  border: '1px solid rgba(220, 20, 60, 0.2)',
                }}
              >
                <Avatar
                  src={cvData.personal.photo}
                  alt={cvData.personal.fullName}
                  sx={{
                    width: 140,
                    height: 140,
                    margin: '0 auto',
                    mb: 2,
                    border: '3px solid',
                    borderColor: 'primary.main',
                    boxShadow: '0 0 20px rgba(220, 20, 60, 0.5)',
                  }}
                >
                  {!cvData.personal.photo &&
                    cvData.personal.fullName
                      .split(' ')
                      .map((n) => n[0])
                      .join('')}
                </Avatar>

                <Typography variant="h4" fontWeight={700} gutterBottom>
                  {cvData.personal.fullName}
                </Typography>

                <Typography variant="h6" color="primary" fontWeight={500}>
                  {cvData.personal.profession}
                </Typography>
              </Paper>

              {/* Sobre mí */}
              <Paper
                elevation={4}
                sx={{
                  p: 2.5,
                  borderRadius: 3,
                  backgroundColor: 'rgba(26, 26, 26, 0.95)',
                  backdropFilter: 'blur(10px)',
                  border: '1px solid rgba(220, 20, 60, 0.2)',
                }}
              >
                <Typography variant="h6" fontWeight={600} gutterBottom>
                  Sobre mí
                </Typography>
                <Typography variant="body1" sx={{ lineHeight: 1.7, textAlign: 'justify' }}>
                  {cvData.personal.description}
                </Typography>
              </Paper>

              {/* Habilidades Técnicas - Carrusel */}
              <Paper
                elevation={4}
                sx={{
                  borderRadius: 3,
                  backgroundColor: 'rgba(26, 26, 26, 0.95)',
                  backdropFilter: 'blur(10px)',
                  overflow: 'hidden',
                  border: '1px solid rgba(220, 20, 60, 0.2)',
                }}
              >
                <Typography
                  variant="h6"
                  fontWeight={600}
                  sx={{
                    px: 2,
                    pt: 1.5,
                    pb: 0.5,
                  }}
                >
                  Habilidades Técnicas
                </Typography>
                <Box 
                  sx={{ 
                    overflow: 'hidden', 
                    width: '100%',
                    maxWidth: '480px',
                    margin: '0 auto',
                  }}
                >
                  <SkillsCarousel skills={cvData.skills} />
                </Box>
              </Paper>
            </Box>

            {/* ========== COLUMNA DERECHA: Educación y Certificaciones ========== */}
            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2.5 }}>
              {/* Educación */}
              <Paper
                elevation={4}
                sx={{
                  p: 3,
                  borderRadius: 3,
                  backgroundColor: 'rgba(255, 255, 255, 0.95)',
                  backdropFilter: 'blur(10px)',
                }}
              >
                <Typography
                  variant="h6"
                  sx={{
                    mb: 2,
                    fontWeight: 600,
                    display: 'flex',
                    alignItems: 'center',
                    gap: 1,
                  }}
                >
                  <SchoolIcon color="primary" />
                  Educación
                </Typography>

                {cvData.education.map((edu) => (
                  <Box key={edu.id} sx={{ mb: 3, '&:last-child': { mb: 0 } }}>
                    <Typography variant="subtitle1" fontWeight={600} color="primary">
                      {edu.degree}
                    </Typography>
                    <Typography variant="body2" color="text.secondary" gutterBottom>
                      {edu.institution}
                    </Typography>
                    <Typography variant="caption" color="text.secondary" sx={{ fontStyle: 'italic' }}>
                      {edu.period}
                    </Typography>
                    {edu.description && (
                      <Typography variant="body2" sx={{ mt: 1, fontSize: '0.85rem' }}>
                        {edu.description}
                      </Typography>
                    )}
                  </Box>
                ))}
              </Paper>

              {/* Certificaciones */}
              <Paper
                elevation={4}
                sx={{
                  p: 3,
                  borderRadius: 3,
                  backgroundColor: 'rgba(255, 255, 255, 0.95)',
                  backdropFilter: 'blur(10px)',
                }}
              >
                <Typography
                  variant="h6"
                  sx={{
                    mb: 2,
                    fontWeight: 600,
                    display: 'flex',
                    alignItems: 'center',
                    gap: 1,
                  }}
                >
                  <EmojiEventsIcon color="primary" />
                  Certificaciones
                </Typography>

                {cvData.certifications.map((cert) => (
                  <Box key={cert.id} sx={{ mb: 2, '&:last-child': { mb: 0 } }}>
                    <Typography variant="subtitle2" fontWeight={600}>
                      {cert.name}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      {cert.issuer} • {cert.year}
                    </Typography>
                  </Box>
                ))}
              </Paper>
            </Box>
          </Box>
        </Container>
      </Box>

      {/* ========== SECCIÓN TABS DINÁMICAS (CON SCROLL) ========== */}
      <Box
        sx={{
          backgroundColor: 'background.paper',
          py: 6,
        }}
      >
        <Container maxWidth="xl">
          <Typography
            variant="h3"
            textAlign="center"
            fontWeight={700}
            gutterBottom
            sx={{ mb: 4 }}
          >
            Explora Más
          </Typography>

          {/* Tabs Navigation */}
          <Paper elevation={3} sx={{ mb: 4, borderRadius: 2 }}>
            <Tabs
              value={activeTab}
              onChange={handleTabChange}
              variant="fullWidth"
              sx={{
                '& .MuiTab-root': {
                  minHeight: 80,
                  textTransform: 'none',
                  fontSize: '1.1rem',
                  fontWeight: 500,
                },
              }}
            >
              <Tab icon={<SportsFootballIcon sx={{ fontSize: 32 }} />} label="Fútbol" iconPosition="top" />
              <Tab icon={<SportsEsportsIcon sx={{ fontSize: 32 }} />} label="Videojuegos" iconPosition="top" />
              <Tab icon={<MenuBookIcon sx={{ fontSize: 32 }} />} label="Biblia" iconPosition="top" />
              <Tab icon={<MovieIcon sx={{ fontSize: 32 }} />} label="Anime" iconPosition="top" />
            </Tabs>
          </Paper>

          {/* Tab Content */}
          <Paper elevation={3} sx={{ borderRadius: 2 }}>
            {activeTab === 0 && <FootballTab />}
            {activeTab === 1 && <VideoGamesTab />}
            {activeTab === 2 && <BibleTab />}
            {activeTab === 3 && <AnimeTab />}
          </Paper>
        </Container>
      </Box>

      {/* Footer */}
      <Box
        sx={{
          background: 'linear-gradient(135deg, #0a0a0a 0%, #1a0a0a 100%)',
          borderTop: '1px solid rgba(220, 20, 60, 0.3)',
          color: 'white',
          py: 3,
          textAlign: 'center',
        }}
      >
        <Container maxWidth="lg">
          <Typography variant="body2">
            © {new Date().getFullYear()} {cvData.personal.fullName}. Todos los derechos reservados.
          </Typography>
          <Typography variant="caption" sx={{ mt: 1, opacity: 0.8, display: 'block' }}>
            CV Interactivo desarrollado con React + TypeScript + Material UI
          </Typography>
        </Container>
      </Box>
    </Box>
  );
}

export default App;
