import { Box, Typography } from '@mui/material';
import { keyframes } from '@mui/system';
import type { TechSkill } from '../../types/cv.types';

interface SkillsCarouselProps {
  skills: TechSkill[];
}

/**
 * Componente de carrusel automático de habilidades técnicas
 * Muestra las habilidades con icono + nombre en movimiento continuo
 */
export const SkillsCarousel = ({ skills }: SkillsCarouselProps) => {
  // Mapeo de tecnologías a iconos
  const getIconForSkill = (skillName: string) => {
    const name = skillName.toLowerCase();
    
    // Frontend
    if (name.includes('react') || name.includes('next')) return '⚛️';
    if (name.includes('javascript') || name.includes('js')) return '🟨';
    if (name.includes('typescript') || name.includes('ts')) return '🔷';
    if (name.includes('html')) return '🌐';
    if (name.includes('css')) return '🎨';
    if (name.includes('material')) return '💎';
    
    // Backend
    if (name.includes('.net') || name.includes('dotnet')) return '🟣';
    if (name.includes('node')) return '🟢';
    if (name.includes('c#')) return '💜';
    
    // Database
    if (name.includes('sql')) return '🗄️';
    if (name.includes('mongo')) return '🍃';
    
    // Tools
    if (name.includes('git')) return '📦';
    if (name.includes('docker')) return '🐳';
    if (name.includes('vs code') || name.includes('vscode')) return '💻';
    
    return '⚙️';
  };

  // Animación de scroll infinito
  const scroll = keyframes`
    0% {
      transform: translateX(0);
    }
    100% {
      transform: translateX(-50%);
    }
  `;

  // Duplicar las habilidades para efecto infinito
  const duplicatedSkills = [...skills, ...skills];

  return (
    <Box
      sx={{
        overflow: 'hidden',
        width: '100%',
        py: 2,
      }}
    >
      <Box
        sx={{
          display: 'flex',
          gap: 1,
          animation: `${scroll} 40s linear infinite`,
          '&:hover': {
            animationPlayState: 'paused',
          },
        }}
      >
        {duplicatedSkills.map((skill, index) => (
          <Box
            key={index}
            sx={{
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              justifyContent: 'center',
              gap: 0.3,
              px: 1,
              py: 0.8,
              borderRadius: 1.5,
              backgroundColor: 'rgba(255, 255, 255, 0.9)',
              boxShadow: 1,
              minWidth: '55px',
              maxWidth: '65px',
              flexShrink: 0,
            }}
          >
            <Typography
              component="span"
              sx={{
                fontSize: '1.5rem',
                lineHeight: 1,
              }}
            >
              {getIconForSkill(skill.name)}
            </Typography>
            <Typography
              component="span"
              sx={{
                fontSize: '0.6rem',
                fontWeight: 500,
                color: 'text.primary',
                textAlign: 'center',
                whiteSpace: 'nowrap',
                overflow: 'hidden',
                textOverflow: 'ellipsis',
                width: '100%',
              }}
            >
              {skill.name}
            </Typography>
          </Box>
        ))}
      </Box>
    </Box>
  );
};
