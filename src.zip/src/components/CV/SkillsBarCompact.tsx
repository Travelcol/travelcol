import { Box, Typography, Tooltip } from '@mui/material';
import type { TechSkill } from '../../types/cv.types';

// Importar iconos de Material UI que representan tecnologías
import CodeIcon from '@mui/icons-material/Code';
import DataObjectIcon from '@mui/icons-material/DataObject';
import StorageIcon from '@mui/icons-material/Storage';
import TerminalIcon from '@mui/icons-material/Terminal';
import WebIcon from '@mui/icons-material/Web';
import ApiIcon from '@mui/icons-material/Api';

interface SkillsBarCompactProps {
  skills: TechSkill[];
}

/**
 * Componente compacto de habilidades técnicas con iconos
 * Diseñado para ocupar menos espacio en el layout
 */
export const SkillsBarCompact = ({ skills }: SkillsBarCompactProps) => {
  // Mapeo de tecnologías a iconos (puedes personalizar esto)
  const getIconForSkill = (skillName: string) => {
    const name = skillName.toLowerCase();
    
    // Frontend
    if (name.includes('react') || name.includes('next')) {
      return '⚛️';
    }
    if (name.includes('javascript') || name.includes('js')) {
      return '🟨';
    }
    if (name.includes('typescript') || name.includes('ts')) {
      return '🔷';
    }
    if (name.includes('html')) {
      return '🌐';
    }
    if (name.includes('css')) {
      return '🎨';
    }
    if (name.includes('material')) {
      return '💎';
    }
    
    // Backend
    if (name.includes('.net') || name.includes('dotnet')) {
      return '🟣';
    }
    if (name.includes('node')) {
      return '🟢';
    }
    if (name.includes('c#')) {
      return '💜';
    }
    
    // Database
    if (name.includes('sql')) {
      return '🗄️';
    }
    if (name.includes('mongo')) {
      return '🍃';
    }
    
    // Tools
    if (name.includes('git')) {
      return '📦';
    }
    if (name.includes('docker')) {
      return '🐳';
    }
    if (name.includes('vs code') || name.includes('vscode')) {
      return '💻';
    }
    
    return '⚙️';
  };

  return (
    <Box>
      <Typography
        variant="h6"
        sx={{
          mb: 2,
          fontWeight: 600,
          display: 'flex',
          alignItems: 'center',
          gap: 1,
        }}
      >
        <CodeIcon color="primary" />
        Habilidades Técnicas
      </Typography>

      <Box
        sx={{
          display: 'flex',
          flexWrap: 'wrap',
          gap: 1.5,
        }}
      >
        {skills.map((skill, index) => (
          <Tooltip key={index} title={skill.name} arrow>
            <Box
              sx={{
                display: 'flex',
                alignItems: 'center',
                gap: 0.5,
                px: 1.5,
                py: 0.75,
                borderRadius: 2,
                backgroundColor: 'primary.light',
                color: 'white',
                fontSize: '0.875rem',
                fontWeight: 500,
                cursor: 'pointer',
                transition: 'all 0.2s',
                '&:hover': {
                  transform: 'translateY(-2px)',
                  boxShadow: 2,
                  backgroundColor: 'primary.main',
                },
              }}
            >
              <span style={{ fontSize: '1.2rem' }}>
                {getIconForSkill(skill.name)}
              </span>
              <span>{skill.name}</span>
            </Box>
          </Tooltip>
        ))}
      </Box>
    </Box>
  );
};
