import type { CVData } from '../types/cv.types';

/**
 * Datos del CV de Juan Arevalo
 * Este archivo contiene toda la información personal, educación, experiencia, etc.
 * Puedes editar estos datos fácilmente para actualizar tu CV
 */

export const cvData: CVData = {
  personal: {
    fullName: 'Juan Arevalo',
    profession: 'Ingeniero de Software',
    description: 'Profesional responsable, trabajador y dispuesto a aprender. Apasionado por el desarrollo de software y las nuevas tecnologías. Con experiencia en desarrollo full-stack y enfoque en crear soluciones eficientes y escalables.',
  },

  education: [
    {
      id: 'edu-1',
      degree: 'Ingeniería de Software',
      institution: 'Universidad Tecnológica',
      period: '2018 - 2022',
      description: 'Formación integral en desarrollo de software, arquitectura de sistemas y metodologías ágiles.',
    },
    // Puedes agregar más educación aquí
  ],

  certifications: [
    {
      id: 'cert-1',
      name: 'JavaScript Fundamentals',
      issuer: 'CISCO',
      year: '2023',
    },
    {
      id: 'cert-2',
      name: 'React Development',
      issuer: 'Plataforma Online',
      year: '2023',
    },
    // Puedes agregar más certificaciones aquí
  ],

  experience: [
    {
      id: 'exp-1',
      company: 'Tech Solutions',
      role: 'Desarrollador Full-Stack',
      period: '2022 - Presente',
      description: 'Desarrollo de aplicaciones web utilizando React, Next.js y .NET. Implementación de bases de datos SQL Server y optimización de rendimiento.',
      technologies: ['React', 'Next.js', '.NET', 'SQL Server'],
    },
    {
      id: 'exp-2',
      company: 'Startup Innovadora',
      role: 'Desarrollador Frontend',
      period: '2021 - 2022',
      description: 'Creación de interfaces de usuario modernas y responsivas. Colaboración en equipo usando metodologías ágiles.',
      technologies: ['React', 'JavaScript', 'Material UI'],
    },
    // Puedes agregar más experiencia aquí
  ],

  contact: {
    email: 'juansearevalo00@gmail.com',
    linkedin: 'https://linkedin.com/in/juanarevalo',
    github: 'https://github.com/juanarevalo',
    phone: '+57 300 123 4567',
  },

  skills: [
    // Frontend
    { name: 'React', category: 'frontend' },
    { name: 'Next.js', category: 'frontend' },
    { name: 'JavaScript', category: 'frontend' },
    { name: 'TypeScript', category: 'frontend' },
    { name: 'HTML5', category: 'frontend' },
    { name: 'CSS3', category: 'frontend' },
    { name: 'Material UI', category: 'frontend' },
    
    // Backend
    { name: '.NET', category: 'backend' },
    { name: 'Node.js', category: 'backend' },
    { name: 'C#', category: 'backend' },
    
    // Database
    { name: 'SQL Server', category: 'database' },
    { name: 'MongoDB', category: 'database' },
    
    // Tools
    { name: 'Git', category: 'tools' },
    { name: 'VS Code', category: 'tools' },
    { name: 'Docker', category: 'tools' },
  ],
};
